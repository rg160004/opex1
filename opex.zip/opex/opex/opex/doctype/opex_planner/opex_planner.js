// Copyright (c) 2022, OpEX Team and contributors
// For license information, please see license.txt

const onRefresh = frm => {
	// console.log(frm.is_dirty())
	console.log(frm.doc);
		
	if (frm.doc.status === 'Initiated')
		frm.add_custom_button('Go to Form', () => {
			if (frm.doc.refdocname) {
				const [docType, docName] = frm.doc.refdocname.split(',')
				// frm.set_value('isredirected',1)
				frappe.set_route(['Form', docType, docName])
			}
		})
	else
	frm.add_custom_button('Create Form', () => {
		frappe.confirm('Are you sure you want to Create and Go To Form?', () => {
			//   console.log(frappe)
			if (frm.doc) {
				const dataObj = {}
				frm.fields.forEach(f => {
					if (f.df.fieldname in frm.doc)
						dataObj[f.df.fieldname] = frm.doc[f.df.fieldname]
				})
				const dataKeys = Object.keys(dataObj)
				// console.log(dataObj)
				if (dataKeys.length) {
					frappe.db
						.insert({
							// docname: 'Test Doc ' + Math.floor(Math.random() * 100000),
							doctype: 'OpEx4',
							...dataObj,
						})
						.then(doc => {
							console.log('Newly created doc:', doc.name, doc)
							// frm.set_value('status', 'Initiated')
							frm.set_value('refdocname', `${doc.doctype},${doc.name}`)
							// if (frm.is_dirty()) 
							frm.save()
							frappe.set_route(['Form', doc.doctype, doc.name])
						})
				}
			}
		})
	})
}

frappe.ui.form.on('OpEx Planner', {
	refresh: onRefresh,
})